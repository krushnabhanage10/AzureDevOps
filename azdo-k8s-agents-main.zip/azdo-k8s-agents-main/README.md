# azdo-k8s-agents
Self-Hosted Azure DevOps agents based on Kubernetes clusters


Read in Blog post: https://moimhossain.com/2021/04/24/elastic-self-hosted-pool-for-azure-devops/
