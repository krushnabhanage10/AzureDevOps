﻿namespace AgentController.Kubes
{
    public class CrdConstants
    {
        public const string Group = "azdo.octolamp.nl";
        public const string Version = "v1";
        public const string CRD_AgentSpecPlural = "agents";
        public const string AgentSpecName = "agent";
    }
}
